</div>
</div>
</div>
<script src="<?= base_url('vendor/jquery/jquery-3.7.1.js') ?>"></script>
<script src="<?= base_url('js/sb-admin-2.js') ?>"></script>
<script src="<?= base_url('js/miJs.js') ?>"></script>

</body>

</html>